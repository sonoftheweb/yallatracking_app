<?php
        Route::controller('ycustomers', 'YcustomersController');
                    Route::controller('cities', 'CitiesController');
                    Route::controller('states', 'StatesController');
                    Route::controller('ycustomersedit', 'YcustomerseditController');
                    Route::controller('accounttypes', 'AccounttypesController');
                    Route::controller('deladdress', 'DeladdressController');
                    Route::controller('admincustdeladdview', 'AdmincustdeladdviewController');
                    Route::controller('paygbalance', 'PaygbalanceController');
                    Route::controller('companybranches', 'CompanybranchesController');
                    Route::controller('zones', 'ZonesController');
                    Route::controller('customergroups', 'CustomergroupsController');
                    Route::controller('basepricing', 'BasepricingController');
                    Route::controller('weightbasedpricing', 'WeightbasedpricingController');
                    Route::controller('prioritypricing', 'PrioritypricingController');
                    Route::controller('viewdeliveries', 'ViewdeliveriesController');
                    Route::controller('getdeliveries', 'GetdeliveriesController');
                    Route::controller('restapi', 'RestapiController');
                    Route::controller('bulkdelivery', 'BulkdeliveryController');
                    ?>